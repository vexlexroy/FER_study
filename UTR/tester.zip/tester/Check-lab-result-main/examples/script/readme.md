# About script option
You have a lot of freedom with script  
For example you can compile your program (if needed)  
Like with makefile.  
But you shouldn't write to stdout (because will your program write there)  
You could write to stderr.  

Anyway, I will demonstrate how to first make jar and then run it.  

For some reason, you cannot directly run powershell script,  
so I used cmd script to run it.  
