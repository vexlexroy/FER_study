import java.util.Scanner;

public class Prog {
	public static void main(String[] args) {
		Logic.func();
	}
}