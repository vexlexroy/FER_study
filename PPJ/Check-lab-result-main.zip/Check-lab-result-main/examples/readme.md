# Stuff in examples/  
- test/ folder that contains test files  
- each of the language option folders  
  with 2 programs:  
  - one that is 100% correct  
  - one that is randomly correct, incorrect, timeouted, or produces "couldn't execute"  
  - and config.json with defaults that should run the correct program succesfully

Correct program should  
input (stdin) 2 integers (after each there is single newline (\n))  
and in each separate line print (stdout) sum (+), difference (-), and product (*)  

Whitespace before and after, in output, doesn't affect the result.  
