# About old/
This is previous spaghetti code.  
I'm leaving it here if someone still wants it.  
